<?php $__env->startSection('content'); ?>
    <div class="brand_color">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="titlepage">
                        <h2>Contact Us</h2>
                    </div>
                </div>
            </div>





        </div>

    </div>















































    <!-- rfq -->


















































    <!-- start rfq -->






























    <!-- end rfq -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\blog\first_project\my_first_project\resources\views/frontend/contact.blade.php ENDPATH**/ ?>