<?php $__env->startSection('content'); ?>

<div class="brand_color">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="titlepage">
                    <h2>about</h2>
                </div>
            </div>
        </div>
    </div>

</div>


<div class="about">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="about_box mt-2" <?php echo e($loop->index == 0 ? 'active' : ''); ?>>

                        <figure><img src="<?php echo e(asset('storage/'.$profile->image)); ?>" alt="<?php echo e($profile->title); ?>" width="193" height="130"/></figure>


                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                <div class="about_box">
                    <h3> <?php echo e($profile->title); ?></h3>

                    <hr>



                    <div class="profile-description">
                        <?php echo $profile->description; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- start CHOOSE -->
<div class="whyshoose border-top">
    <div class="container whyschose">

        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="title">
                    <h2>Why<strong class="black">Choose Us</strong></h2>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="whyschose">
    <div class="choose_bg">
        <div class="container">
            <div class="white_bg">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                        <div class="for_box">
                            
                            <h4 class="one">Founded in 2007</h4>
                            
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                        <div class="for_box">
                            
                            <h4 class="one">11-50 People</h4>
                            
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                        <div class="for_box">
                            
                            <h4 class="one">81% Quick Response</h4>
                            
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                        <div class="for_box">
                            
                            <h4 class="one">
                                <a href="#" class="why-choose">
                                    above 2000 sqm
                                </a>

                            </h4>
                            
                        </div>
                    </div>
                    <div class="col-md-12">
                        <a href="http://127.0.0.1:8000/profile" class="read-more">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end CHOOSE -->

<?php $__env->stopSection(); ?>




<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\blog\first_project\my_first_project\resources\views/frontend/profile.blade.php ENDPATH**/ ?>