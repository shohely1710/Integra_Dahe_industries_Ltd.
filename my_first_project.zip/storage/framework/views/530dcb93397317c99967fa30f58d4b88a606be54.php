<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="card">
                <div class="card-header">
                    Manage Gallery
                </div>
                <div class="card-body">
                    <?php echo $__env->make('backend.layouts.partials.message_product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <table class="table table-hover table-striped">
                        <tr>
                            <th>#</th>
                            <th>Gallery Name</th>
                            <th>Gallery Image</th>
                            <th>Action</th>

                        </tr>

                        <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>#</td>
                                <td><?php echo e($gallery->name); ?></td>
                                <td>
                                    <img src="<?php echo asset('images/galleries/' .$gallery->image); ?>" width="100">
                                </td>

                                <td><a href="<?php echo e(route('admin.gallery.edit', $gallery->id)); ?>" class="btn btn-success">Edit</a>
                                    <a href="#deleteModal<?php echo e($gallery->id); ?>" data-toggle="modal" class="btn btn-danger">Delete</a>

                                    <!-- Modal -->
                                    <div class="modal fade" id="deleteModal<?php echo e($gallery->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Are you sure to delete?</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
                                                    <span aria-hidden="true">&times;</span>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo route('admin.gallery.delete', $gallery->id); ?>"  method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-danger">Permanent Delete</button>

                                                    </form>

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\blog\first_project\my_first_project\resources\views/backend/pages/gallery/index.blade.php ENDPATH**/ ?>