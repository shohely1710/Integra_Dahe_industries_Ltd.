<?php $__env->startSection('content'); ?>
<section class="slider_section">

















































    <div class="our-slider">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">

                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($loop->index); ?>" class="<?php echo e($loop->index == 0 ? 'active' : ''); ?>"></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ol>
            <div class="carousel-inner">

                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($loop->index == 0 ? 'active' : ''); ?>">
                        <img class="d-block w-100" src="<?php echo e(asset('storage/'.$slider->image)); ?>" alt="<?php echo e($slider->title); ?>" style="height: 450px;" />

                        <div class="carousel-caption d-none d-md-block">
                            <h5><?php echo e($slider->title); ?></h5>

                            <?php if($slider->button_text): ?>
                                <p>
                                    <a href="<?php echo e($slider->button_link); ?>" target="_blank" class="btn btn-danger"><?php echo e($slider->button_text); ?></a>
                                </p>
                            <?php endif; ?>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
</section>





<!-- Product_page -->
<div class="service">
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="title">
                      <h2>our <strong class="black">products</strong></h2>
                      <span>We package the products with best services to make you a happy customer.</span>
                    </div>
            </div>
        </div>

    </div>
</div>















<div class="product-bg border-bottom">
    <div class="product-bg-white">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                    <div class="product-box" <?php echo e($loop->index == 0 ? 'active' : ''); ?>>

                      <i><img src="<?php echo asset('images/products/' .$product->image); ?>" alt="<?php echo e($product->title); ?>"  width="100" /></i>
                    <h3>
                        <a href="/product"><span style="color:black"> <?php echo e($product->title); ?> </span></a>
                    </h3>




                    </div>
                </div>


























                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>




    <!-- service -->
    <div class="service">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="title">
                        <h2>our <strong class="black">brands</strong></h2>
                        <span>Easy and effective way to get your device repair</span>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12">
                    <div class="service-box" <?php echo e($loop->index == 0 ? 'active' : ''); ?>>

                            <i><img src="<?php echo e(asset('images/brands/' .$brand->image)); ?>" alt="<?php echo e($brand->name); ?>" width="200" height="150"/></i>
                            <h3> <?php echo e($brand->name); ?> </h3>



                    </div>

                </div>
















        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- CHOOSE  -->


















































<!-- start CHOOSE -->
    <div class="whyshoose border-top">
        <div class="container whyschose">

            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="title">
                        <h2>Why<strong class="black">Choose Us</strong></h2>
                    </div>
                </div>

                </div>
            </div>
        </div>

    <div class="whyschose">
    <div class="choose_bg">
        <div class="container">
            <div class="white_bg">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                        <div class="for_box">
                            <h4 class="one">
                                <a href="#" class="why-choose">
                                Founded in 2007
                                </a>
                            </h4>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                        <div class="for_box">
                            <h4 class="one">
                                <a href="#" class="why-choose">
                                11-50 People
                                </a>
                            </h4>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                        <div class="for_box">
                            <h4 class="one">
                                <a href="#" class="why-choose">
                                81% Quick Response
                                </a>
                            </h4>

                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                        <div class="for_box">
                            <h4 class="one">
                                <a href="#" class="why-choose">
                                Above 2000 sqm
                                </a>
                            </h4>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <a href="http://127.0.0.1:8000/profile" class="read-more">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
   </div>
    <!-- end CHOOSE -->


    <!-- Company Information -->

    <div class="service">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="title">
                        <h2>company <strong class="black">information</strong></h2>
                    </div>
                </div>

                    <div class="container">
                        <div class="white_bg">
                            <div class="row">
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                                    <div class="company_box">
                                        <i class="company-location"><img src="<?php echo e(asset('frontend/icon/i1-removebg-preview.png')); ?>"/></i>
                                        <h3 class="com_in">Country/Region</h3>
                                        <p>Bangladesh,Dhaka</p>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                                    <div class="company_box">
                                        <i><img src="<?php echo e(asset('frontend/icon/i2-removebg-preview.png')); ?>"/></i>
                                        <h3 class="com_in">Year Establish</h3>
                                        <p>2018</p>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                                    <div class="company_box">
                                        <i><img src="<?php echo e(asset('frontend/icon/i3-removebg-preview.png')); ?>"/></i>
                                        <h3 class="com_in">Business Type</h3>
                                        <p>Industrial Company</p>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                                    <div class="company_box">
                                        <i><img src="<?php echo e(asset('frontend/icon/i4-removebg-preview.png')); ?>"/></i>
                                        <h3 class="com_in">Main Products</h3>
                                        <p>Optical Fiber Cable, Network Cable...</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

        </div>
    </div>
<!-- end Company Information -->


        <!-- Company Information img-->
        <div class="company-bg">
        <div class="company">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $coms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="responsive">
                    <div class="gallery" <?php echo e($loop->index == 0 ? 'active' : ''); ?>>
                        <a target="_blank" href="#">
                            <img src="<?php echo asset('images/coms/' .$com->image); ?>" alt="img" width="600" height="400">

                        </a>

                    </div>
                </div>






























        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
        </div>
    </div>

        <!-- end Company Information img -->



<!-- Enterprise core competence -->

<div class="service">
    <div class="E-container  border-top">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="title">
                    <h1><strong class="black">Enterprise core competence</strong></h1>
                </div>
            </div>

            <div class="container">
                <div class="white_bg">
                    <div class="row">
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                            <div class="company_box">
                                <i><img src="<?php echo e(asset('frontend/icon/e1.png')); ?>"/></i>
                                <h3 class="en">R&D Capability</h3>
                                <p>Number of R&D Staff</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                            <div class="company_box">
                                <i><img src="<?php echo e(asset('frontend/icon/e2.png')); ?>"/></i>
                                <h3 class="en">Certifications</h3>
                                <p>Certificates:</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                            <div class="company_box">
                                <i><img src="<?php echo e(asset('frontend/icon/e3.png')); ?>"/></i>
                                <h3 class="en">Trade Capability</h3>
                                <p>Export Percentage:</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
                            <div class="company_box">
                                <i><img src="<?php echo e(asset('frontend/icon/e4.png')); ?>"/></i>
                                <h3 class="en">Quality Control</h3>
                                <p>Qc Staff:</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
    <!-- end Enterprise core competence -->


    <!-- Enterprise img-->
    <div class="enterprise-bg">
        <div class="enterprise">
            <div class="container">
                <div class="row">
                   <?php $__currentLoopData = $enterprises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enterprise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="responsive">
                        <div class="gallery" <?php echo e($loop->index == 0 ? 'active' : ''); ?>>
                            <a target="_blank" href="#">
                                <img src="<?php echo asset('images/enterprise/' .$enterprise->image); ?>" alt="img" width="600" height="400">

                            </a>
                            <div class="desc"> <?php echo e($enterprise->description); ?> </div>

                        </div>
                    </div>






























                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>


<!-- Send message  -->



<!-- start rfq -->



















<!-- contact -->











































<!-- end contact -->
<!-- end rfq -->







<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\blog\first_project\my_first_project\resources\views/frontend/front_index.blade.php ENDPATH**/ ?>