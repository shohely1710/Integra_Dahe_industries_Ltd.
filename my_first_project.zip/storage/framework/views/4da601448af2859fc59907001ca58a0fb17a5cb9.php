<header>
    <!-- header inner -->
    <div class="header">
        <div class="head_top">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                        <div class="top-box">
                            <ul class="sociel_link">
                                <li> <a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li> <a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li> <a href="#"><i class="fa fa-instagram"></i></a></li>
                                <li> <a href="#"><i class="fa fa-linkedin"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                        <div class="search top-box">

                            <form class="form-inline my-2 my-lg-0" action="<?php echo route('search'); ?>" method="get">
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" name="search" placeholder="Search Products" aria-label="Recipient's username">
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-secondary" type="button"><i class="fa fa-search"></i> </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    <!--end header inner-->

    <!--logo-->

    <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                    <div class="full">
                        <div class="center-desk">
                            <div class="logo"> <a href="<?php echo e(asset('frontend/index.html')); ?>"><img src="<?php echo e(asset('frontend/images/d2.png')); ?>" alt="logo" clas/></a> </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-7 col-md-9 col-sm-9">
                    <div class="menu-area">
                        <div class="limit-box">
                            <nav class="main-menu">
                                <ul class="menu-area-main">
                                    <li class="active"> <a href="/">Home</a> </li>
                                    <li> <a href="/profile">Profile</a> </li>











                                    <li class="dropdown">

                                        <a class="dropdown-toggle" data-toggle="dropdown" href="/product">products
                                            </a>
                                        <ul class="dropdown-menu">




                                            <li><a href="/product">Masks machine materials</a></li>
                                            <li><a href="/product">Cable machine+production..</a></li>
                                            <li><a href="/product">Fiber optic cable</a></li>
                                            <li><a href="/product">Fiber optic accessories</a></li>
                                        </ul>

                                    </li>
                                    <li> <a href="/gallery">Gallery</a> </li>
                                    <li> <a href="/contact">Contact</a> </li>

                                </ul>


                            </nav>
                        </div>

                    </div>




































                    </div>
                    </div>
                </div>
        <!-- end header inner -->
</header>
<!-- end header -->
<?php /**PATH C:\Users\User\blog\first_project\my_first_project\resources\views/frontend/header.blade.php ENDPATH**/ ?>