<?php $__env->startSection('content'); ?>

    <div class="brand_color">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="titlepage">
                        <h2>photo gallery</h2>
                    </div>
                </div>
            </div>
        </div>

    </div>


    <!-- Lastestnews -->
<div class="Lastestnews blog">
    <div class="container">

        <div class="row">

            <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 margin">
                <div class="news-box" <?php echo e($loop->index == 0 ? 'active' : ''); ?>>

                    <figure><img src="<?php echo e(asset('images/galleries/' .$gallery->image)); ?>" alt="<?php echo e($gallery->name); ?>" width="100" height="100" /></figure>

                    <h3 style="text-align: center"> <?php echo e($gallery->name); ?> </h3>

                </div>
            </div>













            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>
<!-- end Lastestnews -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\blog\first_project\my_first_project\resources\views/frontend/gallery.blade.php ENDPATH**/ ?>