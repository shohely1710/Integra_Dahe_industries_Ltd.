<?php $__env->startSection('content'); ?>
<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Dashboard</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="index.html">Home</a></li>
                    <li><span>Dashboard</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            <div class="user-profile pull-right">
                <img class="avatar user-thumb" src="<?php echo e(asset('backend/assets/images/author/avatar.png')); ?>" alt="avatar">
                <h4 class="user-name dropdown-toggle" data-toggle="dropdown">Kumkum Rai <i class="fa fa-angle-down"></i></h4>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="#">Message</a>
                    <a class="dropdown-item" href="#">Settings</a>
                    <a class="dropdown-item" href="<?php echo e(route(('logout'))); ?>"
                         onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">

                        Log Out</a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main-panel">
    <div class="content-wrapper">
        <div class="card card-body">
            <h3>Welcome to Admin Panel</h3>
            <br>
            <br>
            <p>
                <a href="<?php echo e(route('home')); ?>" class="btn btn-primary btn-lg" target="_blank">Visit Main Site</a>
            </p>


        </div>
    </div>

</div>


<!-- page title area end -->






















































    <!-- sales report area end -->
    <!-- overview area start -->
























    <!-- overview area end -->
    <!-- market value area start -->

















































































    <!-- market value area end -->
    <!-- row area start -->
































































































































        <!-- latest news area start -->





























        <!-- latest news area end -->
        <!-- exchange area start -->























        <!-- exchange area end -->

    <!-- row area start-->


<!-- main content area end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\blog\first_project\my_first_project\resources\views/backend/pages/dashboard/index.blade.php ENDPATH**/ ?>