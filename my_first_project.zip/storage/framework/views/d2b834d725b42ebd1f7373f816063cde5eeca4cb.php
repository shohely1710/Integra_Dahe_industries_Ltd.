<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="card">
                <div class="card-header">
                    Edit Company Image
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.coms.update', $com->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('backend.layouts.partials.message_product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>











                        <div class="form-group">
                            <label for="oldimage" class="form-label">Company Old Image</label><br>

                            <img src="<?php echo asset('images/coms/' .$com->image); ?>" width="100"><br>

                            <label for="image" class="form-label">Company New Image(optional)</label><br>

                            <img src="<?php echo asset('images/coms/' .$com->image); ?>" width="100">

                            <input type="file" class="form-control" name="image" id="image">

                        </div>

                        <button type="submit" class="btn btn-success">Update Image</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\blog\first_project\my_first_project\resources\views/backend/pages/company_info_image/edit.blade.php ENDPATH**/ ?>