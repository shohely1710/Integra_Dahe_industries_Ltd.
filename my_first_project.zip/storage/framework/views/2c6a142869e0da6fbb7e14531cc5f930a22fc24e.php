<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="card">
                <div class="card-header">
                    Edit Enterprise Image
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.enterprise.update', $enterprise->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('backend.layouts.partials.message_product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        
                        
                        
                        
                        
                        
                        
                        
                        

                        <div class="form-group">
                            <label for="exampleInputPassword1" class="form-label">Description</label>
                            <textarea name="description" rows="8" cols="80" class="form-control" placeholder="Enterprise Description" required value="<?php echo e($enterprise->description); ?>"></textarea>
                        </div>


                        <div class="form-group">
                            <label for="oldimage" class="form-label">Enterprise Old Image</label><br>

                            <img src="<?php echo asset('images/enterprise/' .$enterprise->image); ?>" width="100"><br>

                            <label for="image" class="form-label">Enterprise New Image(optional)</label><br>

                            <img src="<?php echo asset('images/enterprise/' .$enterprise->image); ?>" width="100">

                            <input type="file" class="form-control" name="image" id="image">

                        </div>

                        <button type="submit" class="btn btn-success">Update Image</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\blog\first_project\my_first_project\resources\views/backend/pages/enterprise/edit.blade.php ENDPATH**/ ?>