<!-- sidebar menu area start -->

<div class="sidebar-menu">
    <div class="sidebar-header">
        <div class="logo">
            <a href="index.html"><img src="<?php echo e(asset('backend/assets/images/icon/logo.png')); ?>" alt="logo"></a>
        </div>
    </div>
    <div class="main-menu">
        <div class="menu-inner">
            <nav>
                <ul class="metismenu" id="menu">
                    <li class="active">
                        <a href="javascript:void(0)" aria-expanded="true"><i class="ti-dashboard"></i><span>dashboard</span></a>
                        <ul class="collapse">
                            <li class="active"><a href="http://127.0.0.1:8000/admin">Admin dashboard</a></li>


                        </ul>
                    </li>
                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Manage
                                        Sliders
                                    </span></a>
                        <ul class="collapse">
                            <li><a href="http://127.0.0.1:8000/admin/sliders">Sliders</a></li>

                        </ul>
                    </li>
                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Manage
                                        Profile
                                    </span></a>
                        <ul class="collapse">
                            <li><a href="http://127.0.0.1:8000/admin/profiles">Profiles</a></li>

                        </ul>
                    </li>
                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Manage
                                        Menu
                                    </span></a>
                        <ul class="collapse">
                            <li><a href="http://127.0.0.1:8000/admin/menu">Dropdown menu</a></li>
                            <li><a href="http://127.0.0.1:8000/admin/menu/create">Create Menu</a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Manage
                                        Gallery
                                    </span></a>
                        <ul class="collapse">
                            <li><a href="http://127.0.0.1:8000/admin/gallery">Manage Gallery</a></li>
                            <li><a href="http://127.0.0.1:8000/admin/gallery/create">Create Image</a></li>
                            
                        </ul>
                    </li>

                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Manage
                                        Products
                                    </span></a>
                        <ul class="collapse">
                            <li><a href="http://127.0.0.1:8000/admin/products">Manage Products</a></li>
                            <li><a href="http://127.0.0.1:8000/admin/products/create">Create Products</a></li>
                            
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Manage
                                        Categories
                                    </span></a>
                        <ul class="collapse">
                            <li><a href="http://127.0.0.1:8000/admin/categories">Manage Categories</a></li>
                            <li><a href="http://127.0.0.1:8000/admin/categories/create">Add Categories</a></li>
                            
                        </ul>
                    </li>

                    <li>
                            <a href="javascript:void(0)" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Manage
                                            Brands
                                        </span></a>
                            <ul class="collapse">
                                <li><a href="http://127.0.0.1:8000/admin/brands">Manage Brands</a></li>
                                <li><a href="http://127.0.0.1:8000/admin/brands/create">Add Brands</a></li>
                                
                            </ul>
                    </li>

                    <li>
                            <a href="javascript:void(0)" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Manage
                                            Company_Info_Image
                                        </span></a>
                            <ul class="collapse">
                                <li><a href="http://127.0.0.1:8000/admin/coms">Manage Image</a></li>
                                <li><a href="http://127.0.0.1:8000/admin/coms/create">Add Image</a></li>
                                
                            </ul>
                    </li>

                    <li>
                            <a href="javascript:void(0)" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Manage
                                            Enterprise
                                        </span></a>
                            <ul class="collapse">
                                <li><a href="http://127.0.0.1:8000/admin/enterprise">Manage Image</a></li>
                                <li><a href="http://127.0.0.1:8000/admin/enterprise/create">Add Image</a></li>
                                
                            </ul>
                    </li>




























































































                </ul>
            </nav>
        </div>
    </div>
</div>
<!-- sidebar menu area end -->
<?php /**PATH C:\Users\User\blog\first_project\my_first_project\resources\views/backend/layouts/partials/sidebar.blade.php ENDPATH**/ ?>